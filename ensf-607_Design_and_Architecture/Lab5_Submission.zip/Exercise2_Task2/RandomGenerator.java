import java.util.ArrayList;
import java.util.Random;

public class RandomGenerator {
	volatile ArrayList<Integer> numbers;
	
	public RandomGenerator() {
		numbers = new ArrayList<Integer>();
	}
	
	synchronized public void generateNumber(int lo, int hi) {
		Random r = new Random();
		int randomNumber = r.nextInt(hi - lo + 1) + lo;
		this.numbers.add(randomNumber);
	}
	
	public ArrayList<Integer> getRandomNumber() {
		return this.numbers;
	}
}
