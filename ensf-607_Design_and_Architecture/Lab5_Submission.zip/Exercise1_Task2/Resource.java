
public class Resource {

	volatile int counter;
	
	 synchronized public int increment() {
		return counter++;
	}
	
}
