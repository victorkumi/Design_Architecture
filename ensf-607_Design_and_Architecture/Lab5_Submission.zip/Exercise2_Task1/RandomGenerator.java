import java.util.Random;

public class RandomGenerator {
	int randomNumber;
	String threadName;
	
	public void generateNumber(int lo, int hi) {
		Random r = new Random();
		int randomNumber = r.nextInt(hi - lo + 1) + lo;
		this.randomNumber = randomNumber;
	}
	
	public int getRandomNumber() {
		return this.randomNumber;
	}
	
	public String getThreadName() {
		return this.threadName;
	}
	
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

}
