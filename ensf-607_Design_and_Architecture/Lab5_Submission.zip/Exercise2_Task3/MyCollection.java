import java.util.ArrayList;

public class MyCollection {
	volatile ArrayList<Integer> numberCollection;
	
	public MyCollection() {
		numberCollection = new ArrayList<Integer>();
	}

	synchronized public void add(int randomNumber) {
		numberCollection.add(randomNumber);
		
	}
}
