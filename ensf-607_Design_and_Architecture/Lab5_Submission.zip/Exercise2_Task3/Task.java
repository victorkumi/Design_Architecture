import java.util.Random;

public class Task implements Runnable{
	MyCollection theCollection;
	
	public Task(MyCollection theCollection) {
		this.theCollection = theCollection;
	}
	@Override
	public void run() {
		generateNumber(1, 100);	
//		synchronized(this){
//			generateNumber(1, 100);	
//		}
	}
	
	synchronized private void generateNumber(int lo, int hi) {
		Random r = new Random();
		int randomNumber = r.nextInt(hi - lo + 1) + lo;
		this.theCollection.add(randomNumber);
	}

}
