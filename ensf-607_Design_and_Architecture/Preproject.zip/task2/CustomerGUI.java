import javax.swing.*;
import java.awt.*;
//import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
// createRigidArea(Dimension d) Box.
public class CustomerGUI extends JFrame implements ActionListener{
	private JLabel searchClients, selectTypeSearch, enterSearchParam, searchResult, clientInfo, clientId,
	               fName, lName, address, postalCode, phnNum, clientType;
	private ButtonGroup btnGrp;
	private JRadioButton radioClientId, radiolName, radioClntType;
	private JTextField searchField, infoId, infoFName, infoLName, infoAddress, infoPostCode, infoPhnNum;
	private JTextArea resultDisplay;
	private JButton search, clearSearch, save, delete, clear, clientCard, inventoryCard;
	private JComboBox comboBox;
	private JScrollPane scrollPane;
	private JPanel westFieldAndButtons, eastIdLabelAndInput, eastFNameLabelAndInput, eastLNameLabelAndInput, 
	               eastAddressAndInput, eastPostCodeAndInput, eastPhnAndInput, eastClntTypeAndInput, 
	               eastButtns, northPanel, westPanel, eastPanel, southPanel, masterPanel1, masterPanel2, masterPanel;
	
	public CustomerGUI(String title) {
		makeComponents();
		makeFrameComponent(title);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	
	private void makeComponents() {
		// TODO Auto-generated method stub
		makeWestComponent();
		makeEastComponent();
		makeSouthComponent();
		arrangeAllComponents();
	}

	private void makeSouthComponent() {
		southPanel = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.CENTER);
		southPanel.setLayout(theLayout);
		clientCard = new JButton("Client Management Screen");
		inventoryCard = new JButton("Inventory Management Screen");
		southPanel.add(Box.createVerticalStrut(20));
		southPanel.add(clientCard);
		southPanel.add(inventoryCard);
		
	}

	private void makeEastComponent() {
		JPanel eastHeader = new JPanel();
		FlowLayout headerLayout = new FlowLayout(FlowLayout.CENTER);
		eastHeader.setLayout(headerLayout);
		clientInfo = new JLabel("Client Information");
		Font font = new Font("Courier", Font.BOLD,16);
		clientInfo.setFont(font);
		eastHeader.add(clientInfo);
		makeIdLabelAndInput();
		fNameAndInput();
		lNameAndInput();
		addressAndInput();
		postCodeAndInput();
		phnAndInput();
		clntTypeAndInput();
		eastButtons();
		
		eastPanel = new JPanel();
		eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.Y_AXIS));
		//eastPanel.setLayout(new GridLayout(0,1));
		eastPanel.add(eastHeader);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastIdLabelAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastFNameLabelAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastLNameLabelAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastAddressAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastPostCodeAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastPhnAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastClntTypeAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastButtns);
		
	}

	private void makeWestComponent() {
		searchClients = new JLabel("         Search Clients");
		Font font = new Font("Courier", Font.BOLD,16);
		searchClients.setFont(font);
		selectTypeSearch = new JLabel("Select type of search to be performed:");
		makeRadioButtonGroup();
		enterSearchParam = new JLabel("Enter the search parameter below");
		makeFieldAndButtons();
		searchResult = new JLabel("Search Results");
		resultDisplay = new JTextArea(10, 20);
		//resultDisplay.setMargin(new Insets(10, 10, 10, 10));
		resultDisplay.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 5));
		scrollPane = new JScrollPane(resultDisplay); 
		resultDisplay.setEditable(false);
		
		westPanel = new JPanel();
		//westPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
		westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));
		//westPanel.setLayout(new GridLayout(0,1));
		westPanel.add(searchClients);
		westPanel.add(Box.createVerticalStrut(20));
		westPanel.add(selectTypeSearch);
		westPanel.add(Box.createVerticalStrut(5));
		westPanel.add(radioClientId);
		westPanel.add(radiolName);
		westPanel.add(radioClntType);
		westPanel.add(Box.createVerticalStrut(20));
		westPanel.add(enterSearchParam);
		westPanel.add(Box.createVerticalStrut(10));
		westPanel.add(westFieldAndButtons);
		westPanel.add(Box.createVerticalStrut(10));
		westPanel.add(searchResult);
		westPanel.add(scrollPane);
	}

	private void makeFieldAndButtons() {
		westFieldAndButtons = new JPanel();
		FlowLayout theLayout = new FlowLayout();
		westFieldAndButtons.setLayout(theLayout);
		searchField = new JTextField(10);
		search = new JButton("Search");
		clearSearch = new JButton("Clear Search");
		westFieldAndButtons.add(searchField);
		westFieldAndButtons.add(search);
		westFieldAndButtons.add(clearSearch);
	}

	private void makeIdLabelAndInput() {
		eastIdLabelAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastIdLabelAndInput.setLayout(theLayout);
		clientId = new JLabel("Client ID:   ");
		infoId = new JTextField(5);
		eastIdLabelAndInput.add(clientId);
		eastIdLabelAndInput.add(infoId);
	}
	
	private void fNameAndInput() {
		eastFNameLabelAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastFNameLabelAndInput.setLayout(theLayout);
		fName = new JLabel("First Name:   ");
		infoFName = new JTextField(10);
		eastFNameLabelAndInput.add(fName);
		eastFNameLabelAndInput.add(infoFName);
	}
	
	private void lNameAndInput() {
		eastLNameLabelAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastLNameLabelAndInput.setLayout(theLayout);
		lName = new JLabel("Last Name:   ");
		infoLName = new JTextField(10);
		eastLNameLabelAndInput.add(lName);
		eastLNameLabelAndInput.add(infoLName);
	}
	
	private void addressAndInput() {
		eastAddressAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastAddressAndInput.setLayout(theLayout);
		address = new JLabel("Address:   ");
		infoAddress = new JTextField(10);
		eastAddressAndInput.add(address);
		eastAddressAndInput.add(infoAddress);
		//eastAddressAndInput.add(Box.createRigidArea(new Dimension(10, 1)));
	}
	
	private void postCodeAndInput() {
		eastPostCodeAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastPostCodeAndInput.setLayout(theLayout);
		postalCode = new JLabel(" Postal Code:   ");
		infoPostCode = new JTextField(15);
		eastPostCodeAndInput.add(postalCode);
		eastPostCodeAndInput.add(infoPostCode);
	}
	
	private void phnAndInput() {
		eastPhnAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastPhnAndInput.setLayout(theLayout);
		phnNum = new JLabel("Phone Number:   ");
		infoPhnNum = new JTextField(15);
		//eastPhnAndInput.add(Box.createRigidArea(new Dimension(5, 1)));
		eastPhnAndInput.add(phnNum);
		eastPhnAndInput.add(infoPhnNum);
	}
	
	private void clntTypeAndInput() {
		eastClntTypeAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastClntTypeAndInput.setLayout(theLayout);
		clientType = new JLabel("Client Type:   ");
		String types[] = {"Domestic", "Commercial"};
		comboBox = new JComboBox(types); 
		//eastClntTypeAndInput.add(Box.createRigidArea(new Dimension(5, 1)));
		eastClntTypeAndInput.add(clientType);
		eastClntTypeAndInput.add(comboBox);
	}
	
	private void eastButtons() {
		eastButtns = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastButtns.setLayout(theLayout);
		save = new JButton("Save");
		delete = new JButton("Delete");
		clear = new JButton("Clear");
		//eastButtns.add(Box.createRigidArea(new Dimension(5, 1)));
		eastButtns.add(save);
		eastButtns.add(delete);
		eastButtns.add(clear);
	}

	private void makeRadioButtonGroup() {
		btnGrp = new ButtonGroup();

		radioClientId = new JRadioButton("Client ID");
		radiolName = new JRadioButton("Last Name");
		radioClntType = new JRadioButton("Client Type");
		btnGrp.add(radioClientId);
		btnGrp.add(radiolName);
		btnGrp.add(radioClntType);
	}
	
	private void arrangeAllComponents(){
		Container contentPane = getContentPane();
		westPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2));
		northPanel = new JPanel();
		//westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));
		northPanel.setLayout(new GridLayout(1,2));
		northPanel.add(westPanel);
		northPanel.add(eastPanel);
		masterPanel1 = new JPanel();
		masterPanel1.setLayout(new BoxLayout(masterPanel1, BoxLayout.Y_AXIS));
		masterPanel1.add(northPanel);
		//masterPanel1.add(Box.createVerticalStrut(60));
		//masterPanel1.add(southPanel);
		masterPanel2 = westPanel;
	
		//masterPanel = new JPanel();
		
		JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.addTab("customer", northPanel);
	    tabbedPane.addTab("inventory ", northPanel);
	    
//		contentPane.add("Center", masterPanel);
//		contentPane.add("South", southPanel);
		add(tabbedPane);
		//contentPane.add("South", southPanel);
		//contentPane.add(southPanel, BorderLayout.SOUTH);
	}
	
	private void makeFrameComponent(String title) {
		setTitle(title);
		//setSize(1000,600);
		pack();
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public  static void main(String[] args) {
		CustomerGUI clientGUI = new CustomerGUI("Customer Management Screen");
		//add client manager
		//add controller - shopGUIcontroller
	}

}
