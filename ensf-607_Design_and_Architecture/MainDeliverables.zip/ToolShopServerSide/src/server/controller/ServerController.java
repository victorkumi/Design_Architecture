package server.controller;

//import java.util.ArrayList;
//import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//import server.model.ShopInitializer;

import java.net.*;
import java.io.*;

public class ServerController {
	private Socket aSocket;
	private ServerSocket serverSocket;
	private ObjectOutputStream socketOut;
	private ObjectInputStream socketIn;
	private ExecutorService pool;
	
	public ServerController() {
		try {
			serverSocket = new ServerSocket(9898);
			pool = Executors.newFixedThreadPool(2);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void runServer() {
		System.out.println("Server is running..."); 
		try {
			while (true) {
				aSocket = serverSocket.accept();
				System.out.println("Connection accepted by server");
				socketOut = new ObjectOutputStream(aSocket.getOutputStream());
				socketIn = new ObjectInputStream(aSocket.getInputStream());
				ShopInitializer shopInitializer = new ShopInitializer(socketIn, socketOut);
				pool.execute(shopInitializer);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
        pool.shutdown();
		
		try {
			socketIn.close();
			socketOut.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ServerController myServer = new ServerController();
		myServer.runServer();
	}

}
