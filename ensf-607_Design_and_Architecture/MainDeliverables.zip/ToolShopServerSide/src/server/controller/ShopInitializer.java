package server.controller;

import java.io.*;
import server.model.*;

public class ShopInitializer implements Runnable{
	private DatabaseManager dbManager;
	private ObjectInputStream socketIn;
	private ObjectOutputStream socketOut;
	
	public ShopInitializer(ObjectInputStream socketIn, ObjectOutputStream socketOut) {
		setSocketIn(socketIn);
		setSocketOut(socketOut);
		dbManager = new DatabaseManager();
	}
	


	@Override
	public void run() {
		communicate();
		
	}

	private void communicate() {
		while (true) {
			try {
				Object obj = socketIn.readObject();
				
				if (obj instanceof Customer) {
					System.out.println("processing customer query");
					Object replyObj = dbManager.processCustomerQuery((Customer)obj);
					if (replyObj instanceof CustomerList)
					    socketOut.writeObject((CustomerList)replyObj);
					else
						socketOut.writeObject((Customer)replyObj);
					socketOut.flush();
				}
				else if (obj instanceof Item){
					System.out.println("processing inventory query");
					Object replyObj = dbManager.processInventoryQuery((Item)obj);
					if (replyObj instanceof Inventory)
					    socketOut.writeObject((Inventory)replyObj);
					else
						socketOut.writeObject((Item)replyObj);
					socketOut.flush();
				} 
				else
					break;
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		try {
			socketIn.close();
			socketOut.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}


	public ObjectOutputStream getSocketOut() {
		return socketOut;
	}

	public void setSocketOut(ObjectOutputStream socketOut) {
		this.socketOut = socketOut;
	}

	public ObjectInputStream getSocketIn() {
		return socketIn;
	}

	public void setSocketIn(ObjectInputStream socketIn) {
		this.socketIn = socketIn;
	}
}
