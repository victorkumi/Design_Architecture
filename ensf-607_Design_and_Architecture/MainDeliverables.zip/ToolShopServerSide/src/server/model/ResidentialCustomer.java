package server.model;

import java.io.Serializable;

public class ResidentialCustomer extends Customer{
	private static final String type = "RESIDENTIAL";
	
	public ResidentialCustomer(int id, String fName, String lName, String address, String postCode, String phnNum) {
		super(id, fName, lName, "RESIDENTIAL", address, postCode, phnNum);
		
	}
	
	public String getType() {
		return type;
	}
	
	@Override
	public String toString() {
		String customer = "Id: " + this.ID + "\nFirst Name: " + this.fName + "\nLast Name: " + this.lName 
				+ "\n Address: " + this.address + "\n Postal Code: " + this.postalCode + "\nPhone Number: " + this.phnNumber
				+ "\n Type: " + ResidentialCustomer.type;
		return customer;
	}
}
