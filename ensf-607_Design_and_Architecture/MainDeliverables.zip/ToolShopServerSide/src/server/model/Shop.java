package server.model;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * The Shop class is the first interface of the Back End
 * It takes all the command from the Front end and calls the necessary methods of the backend class objects
 * @author victor
 *
 */
//import java.util.ArrayList;

public class Shop implements Serializable{
	private Inventory theInventory;
	private SupplierList theSupplierList;
	private CustomerList theCustomerList;
	
	public Shop(Inventory theInventory, SupplierList theSuplierList, CustomerList theCustomerList) {
		setTheInventory(theInventory);
		setTheSupplierList(theSuplierList);
		setTheCustomerList(theCustomerList);
	}
	
	public Inventory getTheInventory() {
		return theInventory;
	}
	
	public void setTheInventory(Inventory theInventory) {
		this.theInventory = theInventory;
	}
	
	public SupplierList getTheSupplierList() {
		return theSupplierList;
	}
	
	public void setTheSupplierList(SupplierList theSupplierList) {
		this.theSupplierList = theSupplierList;
	}
	
	public void decreaseItem(int id, String name, int amount) {
		theInventory.decreaseItem(id, name, amount);
	}
	
	public void decreaseItem(int id, int amount) {
		theInventory.decreaseItem(id, null, amount);
	}
	
	public void decreaseItem(String name, int amount) {
		theInventory.decreaseItem(-1, name, amount);
	}
	
	public void increaseItem(int id, int amount) {
		theInventory.increaseItem(id, amount);
	}
	
	public Item searchItem(int id) {
		Item itemStr = theInventory.searchItem(id, null);
		return itemStr;
	}
	
	public Item searchItem(String name) {
		Item itemStr = theInventory.searchItem(-1, name);
		return itemStr;
	}
	
	public ArrayList<Item>  listItems() {   //
		ArrayList<Item> allItems = theInventory.getTheItems();
		return allItems;
	}
	
	public int checkItemQuantity(int id) {
		int quantity = theInventory.checkItemQuantity(id);
		return quantity;
	}
	
	public int checkItemQuantity(String name) {
		int quantity = theInventory.checkItemQuantity(name);
		return quantity;
	}

	public Order printDayOrder() {
		// TODO Auto-generated method stub
		Order order = theInventory.makeDayOrder();
		return order;
	}

	public CustomerList getTheCustomerList() {
		return theCustomerList;
	}

	public void setTheCustomerList(CustomerList theCustomerList) {
		this.theCustomerList = theCustomerList;
	}
}
