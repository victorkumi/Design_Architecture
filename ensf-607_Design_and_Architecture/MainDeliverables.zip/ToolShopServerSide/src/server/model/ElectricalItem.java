package server.model;

public class ElectricalItem extends Item{
	private static final String type = "ELECTRICAL";
	
	public ElectricalItem(int id, String name, int quantity, double price) {
		super(id, name, quantity, price);
	}
	
	public String getType() {
		return type;
	}
	
	@Override
	public String toString() {
		String itemStr =  "Name: " + this.NAME + "\nId: " + this.ID + "\nQuantity: " + this.quantity + 
				"\nPrice: " + this.price + " $"  + "\n Type: " + ElectricalItem.type + "\n        Supplier Details \n" + this.getTheSupplier();
		return itemStr;
	}

}
