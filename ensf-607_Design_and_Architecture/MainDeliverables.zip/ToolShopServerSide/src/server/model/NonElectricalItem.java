package server.model;

public class NonElectricalItem extends Item{
    private static final String type = "NON ELECTRICAL";
	
	public NonElectricalItem(int id, String name, int quantity, double price) {
		super(id, name, quantity, price);
	}
	
	public String getType() {
		return type;
	}
	
	@Override
	public String toString() {
		String itemStr =  "Name: " + this.NAME + "\nId: " + this.ID + "\nQuantity: " + this.quantity + 
				"\nPrice: " + this.price + " $"  + "\n Type: " + NonElectricalItem.type + "\n        Supplier Details \n" + this.getTheSupplier();
		return itemStr;
	}
}
