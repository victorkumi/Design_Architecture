package server.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * A utility class to mimic a DB. It loads the items and suppliers to the program for use
 * @author Victor Tuah Kumi
 * 
 */
public class DatabaseManager {
	public Connection jdbc_connection;
	public PreparedStatement statement;
	public String databaseName = "ToolShop", tableName = "ToolTable", toolTable = "TOOL",
			electricalTable = "ELECTRICAL", supplierTable = "SUPPLIER", internationalTable = "INTERNATIONAL",
			orderTable = "ORDER_DATA", orderLineTable = "ORDERLINE", customerTable = "CUSTOMER", purchasesTable = "PURCHASES";
	
	public String connectionInfo = "jdbc:mysql://localhost:3306/"+databaseName,
				  login          = "victor-kumi",
				  password       = "Gre@8ttworks";
	
	ArrayList<Supplier> suppliers;
	ArrayList<Item> items;
	ArrayList<Customer> customers;
	public DatabaseManager () {
		try{
			// If this throws an error, make sure you have added the mySQL connector JAR to the project
			//Class.forName("com.mysql.jdbc.Driver");
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			
			jdbc_connection = DriverManager.getConnection(connectionInfo, login, password);
			System.out.println("Connected to: " + connectionInfo + "\n");
		}
		catch(SQLException e) { e.printStackTrace(); }
		catch(Exception e) { e.printStackTrace(); }
	}
	
	public Object processCustomerQuery(Customer customer) {
		if (customer.getMessageType().contains("Search")) {  
			CustomerList obj = searchCustomers(customer);
			return obj;
		}
		else if (customer.getMessageType().contains("Delete")) {
			Customer obj = deleteCustomer(customer);
			return obj;
		}
		else if (customer.getMessageType().contains("Save")) {
			Customer obj = addCustomer(customer);
			return obj;
		}
		else
		    return null;
	}
	
	public Object processInventoryQuery(Item tool) {
		if (tool.getMessageContent().contains("List All Tools")) {
			Inventory obj = new Inventory(readItems(), new Order(new ArrayList<OrderLine>()));
			obj.setMessageType("Feedback List All Tools");
			return obj;
		}
		else if (tool.getMessageType().contains("Search Tool")) {
			Item obj = searchTool(tool);
			obj.setMessageType("Feedback Search Tool");
			return obj;
		}
		else if (tool.getMessageType().contains("Search tool and Check Quantity")) {
			Item obj = searchToolAndCheckQuantity(tool);
			obj.setMessageType("Feedback Check Quantity");
			return obj;
		}
		else if (tool.getMessageType().contains("Search tool and check quantity By ID and Decrease")
				|| tool.getMessageType().contains("Search tool and check quantity By Name and Decrease")) {
			Item obj = searchToolAndDecreaseItem(tool);
			obj.setMessageType("Feedback Decrease");
			obj.setMessageContent("Decreased " + obj.getNAME() + " quantity");
			return obj;
		}
		return null;
	}
	
	public Item searchToolAndDecreaseItem(Item tool){
		Item item = searchToolAndCheckQuantity(tool);
		String message = tool.getMessageContentExtra();
		int decreaseAmount = Integer.parseInt(message);
		int availableQuant = item.getQuantity();
		int newQuantity = availableQuant - decreaseAmount;
		item.setQuantity(newQuantity);
		if (newQuantity >= 0 ) {
			try {
			String sql = "UPDATE TOOL SET Quantity=? WHERE ToolID=?";
			statement = jdbc_connection.prepareStatement(sql);
			statement.setString(1, "" + newQuantity);
			statement.setString(2, "" + item.getID());
			statement.executeUpdate();
			statement.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
	
			return item;
		}
		
		return null;
	}

	// Add a customer to the database customer table
	public Customer addCustomer(Customer customer) {
		try{
			String sql = "INSERT INTO " + customerTable + "(ClientID, LName, FName, ClientType, PhoneNum, Address, PostalCode)"
					+ " VALUES (?,?,?,?,?,?,?)";
			statement = jdbc_connection.prepareStatement(sql);
			statement.setInt(1, customer.getID());
			statement.setString(2, customer.getlName());
			statement.setString(3, customer.getfName());
			statement.setString(4, customer.getTheType());
			statement.setString(5, customer.getPhnNumber());
			statement.setString(6, customer.getAddress());
			statement.setString(7, customer.getPostalCode());
			statement.executeUpdate(); 
			statement.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		customer.setMessageType("Update Search Results");
		customer.setMessageContent("Added customer with Id " + customer.getID());
		return customer;
	}
	
	public Customer deleteCustomer(Customer customer) {
		String sql = "DELETE FROM " + customerTable + " WHERE ClientID=?";
		try {
			statement = jdbc_connection.prepareStatement(sql);
			statement.setInt(1, customer.getID());
			statement.executeUpdate();
			statement.close();
		} catch (SQLException e) { e.printStackTrace(); }
		customer.setMessageType("Update Search Results");
		//customer.setMessageContent("Deleted customer with Id " + customer.getID() +"\nName: " + customer.getfName() + " "+ customer.getlName());
		customer.setMessageContent("Deleted customer with Id " + customer.getID());
		return customer;
	}
	
	public CustomerList searchCustomers(Customer customer) {
		CustomerList result = new CustomerList(new ArrayList<Customer>());
		Customer theCustomer;
		String sql ="SELECT * FROM " + customerTable + " WHERE ";
		if (customer.getMessageType().contains("Search Client ID")) {
			sql += "ClientID=?";
		}
		else if (customer.getMessageType().contains("Search Last Name")) {
			sql += "LName=?";
		}
		else
			sql += "ClientType=?";
		ResultSet customers;
		try {
			statement = jdbc_connection.prepareStatement(sql);
			statement.setString(1, ""+customer.getMessageContent());
			customers = statement.executeQuery();
			while(customers.next()) {
				theCustomer = new Customer(
						          customers.getInt("ClientID"),
						          customers.getString("FName"),
						          customers.getString("LName"),
						          customers.getString("ClientType"),
						          customers.getString("Address"),
						          customers.getString("PostalCode"),
						          customers.getString("PhoneNum"));
				result.getTheCustomers().add(theCustomer);
			}
			statement.close();
			return result;
		} catch (SQLException e) { e.printStackTrace(); }
		
		return null;
	}
	
	// This method should search the database table for a tool matching the toolID parameter and return that tool.
	// It should return null if no tools matching that ID are found.	
	public Item searchTool(Item tool) {
		String sql ="SELECT * FROM " + toolTable + " WHERE ";
		if (tool.getMessageType().contains("Search Tool ID")) {
			sql += "ToolID=?";
		}
		else
			sql += "ToolName=?";
		ResultSet theTool;
		try {
			statement = jdbc_connection.prepareStatement(sql);
			statement.setString(1, ""+tool.getMessageContent());
			theTool = statement.executeQuery();
			if(theTool.next())
			{
				Item result = new Item(theTool.getInt("ToolID"),
						        theTool.getString("ToolName"), 
						        theTool.getInt("Quantity"), 
						        theTool.getDouble("Price"));
				result.SetTheType(theTool.getString("ToolType"));
				//ArrayList<Supplier> suppliers = new ArrayList<Supplier>();
				suppliers = readSuppliers();
				int id = theTool.getInt("SupplierID");
				Supplier theSupplier = findSupplier(id);
				result.setTheSupplier(theSupplier);
				return result;
			}
			statement.close();
		
		} catch (SQLException e) { e.printStackTrace(); }
		
		return null;
	}
	
	public Item searchToolAndCheckQuantity(Item tool) {
		String sql ="SELECT * FROM " + toolTable + " WHERE ";
		if (tool.getMessageType().contains("By ID")) {
			sql += "ToolID=?";
		}
		else
			sql += "ToolName=?";
		ResultSet theTool;
		try {
			statement = jdbc_connection.prepareStatement(sql);
			statement.setString(1, ""+tool.getMessageContent());
			theTool = statement.executeQuery();
			if(theTool.next())
			{
				Item result = new Item(theTool.getInt("ToolID"),
						        theTool.getString("ToolName"), 
						        theTool.getInt("Quantity"), 
						        theTool.getDouble("Price"));
				result.SetTheType(theTool.getString("ToolType"));
				//ArrayList<Supplier> suppliers = new ArrayList<Supplier>();
				suppliers = readSuppliers();
				int id = theTool.getInt("SupplierID");
				Supplier theSupplier = findSupplier(id);
				result.setTheSupplier(theSupplier);
				return result;
			}
			statement.close();
		
		} catch (SQLException e) { e.printStackTrace(); }
		
		return null;
	}
	/**
	 * The method reads the items details from database and for each item read,
	 * it creates an item object
	 * @return array list of item objects
	 */
	public ArrayList<Item> readItems(){
		items = new ArrayList<Item>();
		String sql = "SELECT * FROM " + toolTable;
		ResultSet allTools;
		try {
			statement = jdbc_connection.prepareStatement(sql);
			allTools = statement.executeQuery();
			
			while(allTools.next()) {
				int supplierId = allTools.getInt("SupplierID");
				//Supplier theSupplier = findSupplier(supplierId);
				if (true) {                                                       //theSupplier != null
					Item myItem =  new Item(allTools.getInt("ToolID"),
							allTools.getString("ToolName"), 
							allTools.getInt("Quantity"),
							allTools.getDouble("Price"));
					myItem.SetTheType(allTools.getString("ToolType"));
					//myItem.setTheSupplier(theSupplier);
					items.add(myItem);
					//theSupplier.getTheItems().add(myItem);
					//supplyItems;
				}
			}
			statement.close();
		} catch (SQLException e) { e.printStackTrace(); }
		
		return items;
		}
	
	/**
	 * The method reads the supplier details from database
	 * and creates an array list of all supplier objects
	 * @return supplier array list
	 */
	public ArrayList<Supplier>  readSuppliers(){
		suppliers = new ArrayList<Supplier>();
		String sql = "SELECT * FROM " + supplierTable;
		ResultSet allSuppliers;
		try {
			statement = jdbc_connection.prepareStatement(sql);
			allSuppliers = statement.executeQuery();
			
			while(allSuppliers.next())
			{
				Supplier supplier =  new Supplier(allSuppliers.getInt("SupplierID"),
								allSuppliers.getString("SupplierName"), 
								allSuppliers.getString("CName"),
								allSuppliers.getString("SupplierType"), 
								allSuppliers.getString("Address"), 
						        allSuppliers.getString("Phone"));
				suppliers.add(supplier);
			}
			statement.close();
		
		} catch (SQLException e) { e.printStackTrace(); }
		
		return suppliers;
	}
	
	public ArrayList<Customer>  readCustomers(){
		customers = new ArrayList<Customer>();
		String sql = "SELECT * FROM " + customerTable;
		ResultSet allCustomers;
		try {
			statement = jdbc_connection.prepareStatement(sql);
			allCustomers = statement.executeQuery();
			
			while(allCustomers.next())
			{
				Customer customer =  new Customer(allCustomers.getInt("ClientID"),
						        allCustomers.getString("FName"), 
						        allCustomers.getString("LName"),
						        allCustomers.getString("ClientType"), 
								allCustomers.getString("Address"), 
								allCustomers.getString("PostalCode"),
						        allCustomers.getString("PhoneNum"));
				customers.add(customer);
			}
			statement.close();
		
		} catch (SQLException e) { e.printStackTrace(); }
		
		return customers;
	}
	

    
	/**
	 * The helper method finds the supplier object and returns it
	 * @param supplierId is the id of the supplier
	 * @return supplier object
	 */
	public Supplier findSupplier(int supplierId) {
		// TODO Auto-generated method stub
		Supplier theSupplier = null;
		for (Supplier s : suppliers) {
			if (s.getId() == supplierId) {
				theSupplier = s;
				//System.out.println(s);
				//break;
			}
		}
		return theSupplier;
	}
}
