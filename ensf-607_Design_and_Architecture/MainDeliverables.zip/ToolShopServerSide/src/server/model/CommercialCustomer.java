package server.model;

public class CommercialCustomer extends Customer{
	private static final String type = "COMMERCIAL";
	
	public CommercialCustomer(int id, String fName, String lName, String address, String postCode, String phnNum) {
		super(id, fName, lName, "COMMERCIAL",address, postCode, phnNum);
		
	}
	
	public String getType() {
		return type;
	}
	
	@Override
	public String toString() {
		String customer = "Id: " + this.ID + "\nFirst Name: " + this.fName + "\nLast Name: " + this.lName 
				+ "\n Address: " + this.address + "\n Postal Code: " + this.postalCode + "\nPhone Number: " + this.phnNumber
				+ "\n Type: " + CommercialCustomer.type;
		return customer;
	}
}
