package server.model;

import java.io.Serializable;

/**
 * The class represents the blueprint of items
 * @author victor
 *
 */
public class Item implements Serializable{
	protected int ID;
	protected String NAME;
	protected int quantity;
	protected double price;
	protected String theType;
	protected Supplier theSupplier;
	public String messageType;
	public String messageContent;
	public String messageContentExtra;
	
	public Item(int id, String name, int quantity, double price) {
		setID(id);
		setNAME(name);
		setQuantity(quantity);
		setPrice(price);
		//setTheSupplier(theSupplier);
	} 
	
	public Item (String messageType, String messageContent) {
		setMessageType(messageType);
		setMessageContent(messageContent);
	}
	
	public Item (String messageType, String messageContent, String messageContentExtra) {
		setMessageType(messageType);
		setMessageContent(messageContent);
		setMessageContentExtra(messageContentExtra);
	}
	
	public void setMessageContentExtra(String messageContentExtra) {
		this.messageContentExtra = messageContentExtra;
		
	}
	
	public String getMessageContentExtra() {
		return messageContentExtra;
	}

	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;	
	}
	
	public void setTheSupplier(Supplier theSupplier) {
		this.theSupplier = theSupplier;
	}

	public Supplier getTheSupplier() {
		return theSupplier;
	}

	public int getID() {
		// TODO Auto-generated method stub
		return this.ID;
	}

	public void decreaseItem(int amount) {
		// TODO Auto-generated method stub
		quantity -= amount;
	}
	
	public String getMessageContent() {
		return messageContent;
	}
	
	public String getMessageType() {
		return messageType;
	}

	public String getNAME() {
		// TODO Auto-generated method stub
		return this.NAME;
	}

	public void setID(int id) {
		ID = id;
	}
	
	public void SetTheType(String theType) {
		this.theType = theType;
	}
	
	public String getTheType() {
		return this.theType;
	}

	public void setNAME(String name) {
		NAME = name;
	}

	public void increaseItem(int amount) {
		// TODO Auto-generated method stub
		quantity += amount;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public OrderLine generateOrderLine() {
		// TODO Auto-generated method stub
		OrderLine newOrderLine = new OrderLine(this);
		//System.out.println(newOrderLine.getQuantity());
		//OrderLine newLine = newOrderLine.generateOrderLine(this, 50 - this.quantity);
		return newOrderLine;
	}
	
//	@Override
//	public String toString() {
//		String itemStr =  "Name: " + this.NAME + "\nId: " + this.ID + "\nQuantity: " + this.quantity + 
//				"\nPrice: " + this.price + " $"  + "\n Type: " + this.theType + "\n        Supplier Details \n" + this.getTheSupplier();
//		return itemStr;
//	}
	
	@Override
	public String toString() {
		String itemStr =  "Name: " + this.NAME + "\nId: " + this.ID + "\nQuantity: " + this.quantity + 
				"\nPrice: " + this.price + " $"  + "\nType: " + this.theType;
		return itemStr;
	}
}
