package server.model;

import java.io.Serializable;

/**
 * The class makes an orderline
 * @author victor
 *
 */
public class OrderLine implements Serializable{
	private Item theItem;
	private int quantity;

    public OrderLine(Item theItem) {
    	setTheItem(theItem);
		setQuantity(50 - theItem.getQuantity());
    }
    
	public Item getTheItem() {
		return theItem;
	}

	public void setTheItem(Item theItem) {
		this.theItem = theItem;
	}

	
	public String toString() {
		String str = "Item Description:      " + this.theItem.getNAME() + "\nAmount ordered:        " + this.quantity
				+ "\nSupplier:              " + this.theItem.getTheSupplier().getTheCompanyName() + "\n";
		return str;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
