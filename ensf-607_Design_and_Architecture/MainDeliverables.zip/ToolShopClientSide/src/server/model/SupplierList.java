package server.model;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * The supplierList contains the list of all suppliers to the shop
 * @author victor
 *
 */
public class SupplierList implements Serializable{
	private ArrayList<Supplier> theSuppliers;
	
	public SupplierList(ArrayList<Supplier> theSuppliers) {
		setTheSuppliers(theSuppliers);
	}

	public ArrayList<Supplier> getTheSuppliers() {
		return theSuppliers;
	}

	public void setTheSuppliers(ArrayList<Supplier> theSuppliers) {
		this.theSuppliers = theSuppliers;
	}
	
}
