package server.model;
import java.util.ArrayList;
import java.util.Random;
import java.util.Date;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
/**
 * The class makes the day's order
 * @author victor
 *
 */
public class Order implements Serializable{
	private ArrayList<OrderLine> theOrderLines;
	
	public Order(ArrayList<OrderLine> theOrderLines) {
		setTheOrderLines(theOrderLines);
	}

	public ArrayList<OrderLine> getTheOrderLines() {
		return theOrderLines;
	}

	public void setTheOrderLines(ArrayList<OrderLine> theOrderLines) {
		this.theOrderLines = theOrderLines;
	}
	
	public void addOrderLine(OrderLine orderLine) {
		theOrderLines.add(orderLine);
	}
	
	@Override
	public String toString() {
		Random random = new Random();
		String id = "";
		for (int i = 0; i < 5; i++) {
			id += random.nextInt(10);
		}
		
		Date date = new Date();
		DateFormat df  = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		String today = df.format(date);
		
		String str = "ORDER ID:              " + id + "\nDATE ORDERED:          " + today + "\n\n";
		for (OrderLine orderLine : theOrderLines) {
			str += orderLine + "\n";
		}
		return str;
	}
	
	public Order makeOrder() {
		try {
			if (theOrderLines.isEmpty())
				return null;
			File f = new File("order.txt");
			FileOutputStream fstream = new FileOutputStream(f);
			
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fstream));
			
			bw.write("-----------------------------------------\n" + this + "");

			bw.write("-----------------------------------------\n");
			bw.close();
		}catch (Exception e) {
			System.out.println(e.getMessage());}
		return this;
	}
}
