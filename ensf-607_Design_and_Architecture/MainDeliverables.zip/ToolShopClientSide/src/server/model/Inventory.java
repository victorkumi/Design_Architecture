package server.model;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * The Inventory class holds the inventory of the shop
 * @author Victor Tuah Kumi
 *
 */
public class Inventory implements Serializable{
	private ArrayList<Item> theItems;
	private Order theOrder;
	public String messageType;
	public String messageContent;
	
	public Inventory(ArrayList<Item> theItems, Order theOrder) {
		setTheItems(theItems);
		setTheOrder(theOrder);
		//makeInitialOrder();
	}
	
	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;	
	}
	
	public String getMessageContent() {
		return messageContent;
	}
	
	public String getMessageType() {
		return messageType;
	}

	public ArrayList<Item> getTheItems() {
		return theItems;
	}

	public void setTheItems(ArrayList<Item> theItems) {
		this.theItems = theItems;
	}

	public Order getTheOrder() {
		return theOrder;
	}

	public void setTheOrder(Order theOrder) {
		this.theOrder = theOrder;
	}
    
	/**
	 * Calls the decreaseItem method in item to decrease item quantity
	 * @param id of item; -1 if no id provided
	 * @param name of item; null if no name is provided
	 * @param amount to decrease item by
	 */
	public void decreaseItem(int id, String name, int amount) {
		// TODO Done
		if(id == -1) {
			decreaseByName(name, amount);
		}
		
		else {
			decreaseById(id, amount);
		}
		
	}
    
	/**
	 * Calls the decreaseItem method in item to decrease item quantity by id
	 * @param id of item to decrease quantity
	 * @param amount to decrease item by
	 */
	private void decreaseById(int id, int amount) {
		// TODO Done
		for (Item item : theItems) {
			if (item.getID() == id) {
				checkDecreaseOrder(item, amount);
				
			}
		}
	}
	/**
	 * The method checks the if the quantity of items in stock is less than 40
	 * and call method to create order lines or decrease the item quantity
	 * @param item the item to check quantity
	 * @param amount to decrease the item by. i.e the amount of items been sold
	 */
    private void checkDecreaseOrder(Item item, int amount) {
		// TODO Auto-generated method stub
    	if (item.getQuantity() > amount) {
			item.decreaseItem(amount);
		}
		if (item.getQuantity() < 40) {
			for (OrderLine orderLine : theOrder.getTheOrderLines()) {
				if (orderLine.getTheItem().getID() == item.getID()) {
					return;
				}
			}
			
			System.out.println(item.getNAME() + " stock below '40', making orderline.\n");
			OrderLine newOrderLine = item.generateOrderLine();

			theOrder.getTheOrderLines().add(newOrderLine);
				
		}
	}

	/**
     * Calls the decreaseItem method in item to decrease item quantity by name
     * @param name of item to decrease quantity
     */
	private void decreaseByName(String name, int amount) {
		// TODO Done
		for (Item item: theItems) {
			if (item.getNAME().equals(name)) {
				checkDecreaseOrder(item, amount);
			}
		}
		
	}
    
	/**
	 * Calls the increaseItem method in item to increase item quantity
	 * @param id of item to increase quantity
	 * @param amount of quantity to increase by
	 */
	public void increaseItem(int id, int amount) {
		// TODO Auto-generated method stub
		for (Item item : theItems) {
			if (item.getID() == id) {
				item.increaseItem(amount);
			}
		}
	}
	
	public Item searchItem(int id, String name) {
		Item item;
		if (id == -1) {
			item = searchByName(name);
		}
		else {
			item = searchById(id);
		}
		return item;
	}

	private Item searchById(int id) {
		// TODO Auto-generated method stub
		for (Item item : theItems) {
			if (item.getID() == id) {
				return item;
			}
		}
		return null;
	}
	
	private Item searchByName(String name) {
		for (Item item: theItems) {
			if (item.getNAME().equals(name)) {
				return item;
			}
		}
		return null;
	}
	
	@Override
	public String toString() {
		String str = "";
		for (Item item : theItems) {
			str += item + "\n\n";
		}
		return str;
	}

	public int checkItemQuantity(int id) {
		// TODO Auto-generated method stub
		for (Item item : theItems) {
			if (item.getID() == id)
				return item.getQuantity();
		}
		return 0;
	}

	public int checkItemQuantity(String name) {
		// TODO Auto-generated method stub
		for (Item item: theItems) {
			if (item.getNAME().equals(name)) {
				return item.getQuantity();
			}
		}
		return 0;
	}

	public Order makeDayOrder() {
		// TODO Auto-generated method stub
		Order order = theOrder.makeOrder();
		return order;
	}
	
	public void makeInitialOrder() {
		System.out.println("\nChecking for possible initial order lines after opening shop......");
		for (Item item : theItems) {
			if (item.getQuantity() < 40)
				checkDecreaseOrder(item, 0);
		}
		System.out.println("Done checking\n");
	}
	
}
