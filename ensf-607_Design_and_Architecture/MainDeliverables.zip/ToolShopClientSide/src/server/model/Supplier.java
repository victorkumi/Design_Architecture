package server.model;
import java.io.Serializable;
import java.util.ArrayList;
/**
 * The supplier class contains the details of the supplier of items to the shop
 * @author victor
 *
 */
public class Supplier implements Serializable{
	private int id;
	private String theCompanyName;
	private String theType;
	private String theAddress;
	private String theSalesContact;
	private String theName;
	private ArrayList<Item> theItems;
	
	public Supplier(int id, String theName, String theCompanyName, String theType, String theAddress, String theSalesContact) {
		setId(id);
		setCompanyName(theCompanyName);
		setTheAddress(theAddress);
		setTheSalesContact(theSalesContact);
		setTheName(theName);
		setTheType(theType);
		setTheItems(new ArrayList<Item>());
	}

	public ArrayList<Item> getTheItems() {
		return theItems;
	}

	public void setTheItems(ArrayList<Item> theItems) {
		this.theItems = theItems;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTheCompanyName() {
		return theCompanyName;
	}

	public void setCompanyName(String companyName) {
		this.theCompanyName = companyName;
	}

	public String getTheAddress() {
		return theAddress;
	}

	public void setTheAddress(String theAddress) {
		this.theAddress = theAddress;
	}

	public String getTheSalesContact() {
		return theSalesContact;
	}

	public void setTheSalesContact(String theSalesContact) {
		this.theSalesContact = theSalesContact;
	}
	
	@Override
	public String toString() {
//		String supplies;
//		for (Item item : theItems) {
//			if (item.getTheSupplier())
//		}
		
		String itemStr =  "Company Name: " + this.theCompanyName + "\nId: " + this.id + "\nAddress: " + this.theAddress + 
				"\nSales Contact: " + this.theSalesContact + "\n      Items Supplied by " + this.theCompanyName + "\n";
		for (Item item : theItems) {
			itemStr += item.getNAME() + "\n";
		}
		
		return itemStr + "\n-------\n\n";
	}

	public String getTheName() {
		return theName;
	}

	public void setTheName(String theName) {
		this.theName = theName;
	}

	public String getTheType() {
		return theType;
	}

	public void setTheType(String theType) {
		this.theType = theType;
	}
}
