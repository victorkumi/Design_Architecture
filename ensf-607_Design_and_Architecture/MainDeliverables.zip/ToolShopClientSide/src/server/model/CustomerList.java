package server.model;
import java.io.Serializable;
import java.util.ArrayList;

public class CustomerList implements Serializable{
	private ArrayList<Customer> theCustomers;
	
	public CustomerList(ArrayList<Customer> theCustomers) {
		setTheCustomers(theCustomers);
	}

	public ArrayList<Customer> getTheCustomers() {
		return theCustomers;
	}

	public void setTheCustomers(ArrayList<Customer> customers) {
		this.theCustomers = customers;
	}
	
	@Override
	public String toString() {
		String str = "";
		for (Customer customer : theCustomers) {
			str += customer + "\n\n";
		}
		return str;
	}
	
}
