package server.model;

import java.io.Serializable;

public class Customer implements Serializable{
	protected int ID;
	protected String fName;
	protected String lName;
	protected String address;
	protected String postalCode;
	protected String phnNumber;
	protected String theType;
	public String messageType;
	public String messageContent;
	//protected ArrayList<Purchases> allPurchases;
	public Customer(int id, String fName, String lName, String theType, String address, String postCode, String phnNum) {
		setID(id);
		setfName(fName);
		setlName(lName);
		setTheType(theType);
		setAddress(address);
		setPostalCode(postCode);
		setPhnNumber(phnNum);
	}
	
	public Customer (String messageType, String messageContent) {
		setMessageType(messageType);
		setMessageContent(messageContent);
	}
	

	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;	
	}

	public void setID(int id) {
		this.ID = id;	
	}
	
	public int getID() {
		return ID;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPhnNumber() {
		return phnNumber;
	}

	public void setPhnNumber(String phnNumber) {
		this.phnNumber = phnNumber;
	}
	
	public void setTheType(String theType) {
		this.theType = theType;
	}
	
	public String getTheType() {
		return this.theType;
	}
	
	public String getMessageContent() {
		return messageContent;
	}
	
	public String getMessageType() {
		return messageType;
	}
	
	@Override
	public String toString() {
		String strCustomer = "Id: " + this.ID + "\nFirst Name: " + this.fName + "\nLast Name: " + this.lName +
				"\nAddress: " + this.address + "\nPostal Code: " + this.postalCode + "\nPhone Number: " + 
				this.phnNumber + "\nType: " + this.theType;
		return strCustomer;
	}
	
}
