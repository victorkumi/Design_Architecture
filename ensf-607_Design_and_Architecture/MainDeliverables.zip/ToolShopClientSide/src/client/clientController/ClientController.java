package client.clientController;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import client.view.ToolShopGUI;
import client.viewController.CustomerController;
import client.viewController.InventoryController;
import server.model.Customer;
import server.model.CustomerList;
import server.model.Inventory;
import server.model.Item;

public class ClientController {
	private ObjectOutputStream socketOut;
	private ObjectInputStream socketIn; 
	private Socket aSocket;
	
	public ClientController(String serverName, int portNumber) {
		try {
			aSocket = new Socket(serverName, portNumber);
			socketIn = new ObjectInputStream(aSocket.getInputStream());
			socketOut = new ObjectOutputStream(aSocket.getOutputStream());
		}catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void operateShop() {
		ToolShopGUI clientGUI = new ToolShopGUI("Tool Shop Management App");
		CustomerController customerController = new CustomerController(clientGUI.getTheCustomerView(), socketOut);
		InventoryController inventoryController = new InventoryController(clientGUI.getTheInventoryView(), socketOut);
		try {
        	while (true) {
			Object obj = socketIn.readObject();
			if (obj instanceof CustomerList || obj instanceof Customer) {
				customerController.processServerReply(obj);
				System.out.println("customerlist instance"); 

			}
			
			else if (obj instanceof Inventory || obj instanceof Item) {
				inventoryController.processServerReply(obj);
			}
			
        	}	

		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ClientController controller = new ClientController("127.0.0.1", 9898);
		controller.operateShop();
		
        
        
	}

}
