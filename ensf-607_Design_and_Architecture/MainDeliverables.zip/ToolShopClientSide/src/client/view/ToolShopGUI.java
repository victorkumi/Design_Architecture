package client.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
// createRigidArea(Dimension d) Box.
public class ToolShopGUI extends JFrame {
	private JPanel theInventoryPanel, theCustomerPanel;
	private InventoryView theInventoryView;
	private CustomerView theCustomerView;
	private JTabbedPane tabbedPane;
	
	public ToolShopGUI(String title) {
		setInventoryViewAndPanel();
		setCustomerViewAndPanel();
		makeTabbedPane();
		makeFrameAndShow(title);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	public CustomerView getTheCustomerView() {
		return theCustomerView;
	}
	
	private void setInventoryViewAndPanel() {
		setTheInventoryView();
		setTheInventoryPanel();
	}
	
	private void setCustomerViewAndPanel() {
		setTheCustomerView();
		setTheCustomerPanel();
	}
	
	private void setTheCustomerPanel() {
		theCustomerPanel = theCustomerView.getTheCustomerPanel();
	}


	private void setTheCustomerView() {
		theCustomerView = new CustomerView();	
	}


	private void setTheInventoryPanel() {
		theInventoryPanel = theInventoryView.getTheInventoryPanel();	
	}


	private void setTheInventoryView() {
		theInventoryView = new InventoryView();
	}
	
	
	private void makeTabbedPane(){	
		tabbedPane = new JTabbedPane();
		tabbedPane.addTab("customer", theCustomerPanel);
	    tabbedPane.addTab("inventory ", theInventoryPanel);
	}
	
	private void makeFrameAndShow(String title) {
		add(tabbedPane);
		setTitle(title);
		pack();
		setVisible(true);
	}

	public InventoryView getTheInventoryView() {
		return theInventoryView;
	}

//	@Override
//	public void actionPerformed(ActionEvent arg0) {
//		// TODO Auto-generated method stub
//		
//	}
	
//	public  static void main(String[] args) {
//		ToolShopGUI clientGUI = new ToolShopGUI("Tool Shop Management App");
//	}

}
