package client.view;

//import javax.swing.ButtonGroup;
//import javax.swing.JButton;
//import javax.swing.JComboBox;
//import javax.swing.JLabel;
//import javax.swing.JPanel;
//import javax.swing.JRadioButton;
//import javax.swing.JScrollPane;
//import javax.swing.JTextArea;
//import javax.swing.JTextField;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class CustomerView {
	private JLabel searchClients, selectTypeSearch, enterSearchParam, searchResult, clientInfo, clientId,
                   fName, lName, address, postalCode, phnNum, clientType;
    private ButtonGroup btnGrp;
    private JRadioButton radioClientId, radiolName, radioClntType;
    private JTextField searchField, infoId, infoFName, infoLName, infoAddress, infoPostCode, infoPhnNum;
    private JTextArea resultDisplay;
    private JButton search, clearSearch, save, delete, clear;
    private JComboBox comboBox;
    private JScrollPane scrollPane;
    private JPanel westFieldAndButtons, eastIdLabelAndInput, eastFNameLabelAndInput, eastLNameLabelAndInput, eastAddressAndInput, eastPostCodeAndInput, 
                   eastPhnAndInput, eastClntTypeAndInput, eastButtns, customerPanel, westPanel, eastPanel;

    public CustomerView() {
    	makeCustomerComponent();
    }
    
    private void makeCustomerComponent() {
		makeWestComponent();
		makeEastComponent();
		arrangeAllComponents();
	}
    
    private void makeEastComponent() {
		JPanel eastHeader = new JPanel();
		FlowLayout headerLayout = new FlowLayout(FlowLayout.CENTER);
		eastHeader.setLayout(headerLayout);
		clientInfo = new JLabel("Client Information");
		Font font = new Font("Courier", Font.BOLD,16);
		clientInfo.setFont(font);
		eastHeader.add(clientInfo);
		makeIdLabelAndInput();
		fNameAndInput();
		lNameAndInput();
		addressAndInput();
		postCodeAndInput();
		phnAndInput();
		clntTypeAndInput();
		eastButtons();
		
		eastPanel = new JPanel();
		eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.Y_AXIS));
		//eastPanel.setLayout(new GridLayout(0,1));
		eastPanel.add(eastHeader);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastIdLabelAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastFNameLabelAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastLNameLabelAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastAddressAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastPostCodeAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastPhnAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastClntTypeAndInput);
		eastPanel.add(Box.createVerticalStrut(20));
		eastPanel.add(eastButtns);
		
	}

	private void makeWestComponent() {
		searchClients = new JLabel("         Search Clients");
		Font font = new Font("Courier", Font.BOLD,16);
		searchClients.setFont(font);
		selectTypeSearch = new JLabel("Select type of search to be performed:");
		makeRadioButtonGroup();
		enterSearchParam = new JLabel("Enter the search parameter below");
		makeFieldAndButtons();
		searchResult = new JLabel("Search Results");
		resultDisplay = new JTextArea(10, 20);
		//resultDisplay.setMargin(new Insets(10, 10, 10, 10));
		resultDisplay.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 5));
		scrollPane = new JScrollPane(resultDisplay); 
		resultDisplay.setEditable(false);
		
		westPanel = new JPanel();
		//westPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
		westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));
		//westPanel.setLayout(new GridLayout(0,1));
		westPanel.add(searchClients);
		westPanel.add(Box.createVerticalStrut(20));
		westPanel.add(selectTypeSearch);
		westPanel.add(Box.createVerticalStrut(5));
		westPanel.add(radioClientId);
		westPanel.add(radiolName);
		westPanel.add(radioClntType);
		westPanel.add(Box.createVerticalStrut(20));
		westPanel.add(enterSearchParam);
		westPanel.add(Box.createVerticalStrut(10));
		westPanel.add(westFieldAndButtons);
		westPanel.add(Box.createVerticalStrut(10));
		westPanel.add(searchResult);
		westPanel.add(scrollPane);
	}
	
	private void makeFieldAndButtons() {
		westFieldAndButtons = new JPanel();
		FlowLayout theLayout = new FlowLayout();
		westFieldAndButtons.setLayout(theLayout);
		searchField = new JTextField(10);
		search = new JButton("Search");
		clearSearch = new JButton("Clear Search");
		westFieldAndButtons.add(searchField);
		westFieldAndButtons.add(search);
		westFieldAndButtons.add(clearSearch);
	}

	private void makeIdLabelAndInput() {
		eastIdLabelAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastIdLabelAndInput.setLayout(theLayout);
		clientId = new JLabel("Client ID:   ");
		infoId = new JTextField(5);
		eastIdLabelAndInput.add(clientId);
		eastIdLabelAndInput.add(infoId);
	}
	
	private void fNameAndInput() {
		eastFNameLabelAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastFNameLabelAndInput.setLayout(theLayout);
		fName = new JLabel("First Name:   ");
		infoFName = new JTextField(10);
		eastFNameLabelAndInput.add(fName);
		eastFNameLabelAndInput.add(infoFName);
	}
	
	private void lNameAndInput() {
		eastLNameLabelAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastLNameLabelAndInput.setLayout(theLayout);
		lName = new JLabel("Last Name:   ");
		infoLName = new JTextField(10);
		eastLNameLabelAndInput.add(lName);
		eastLNameLabelAndInput.add(infoLName);
	}
	
	private void addressAndInput() {
		eastAddressAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastAddressAndInput.setLayout(theLayout);
		address = new JLabel("Address:   ");
		infoAddress = new JTextField(10);
		eastAddressAndInput.add(address);
		eastAddressAndInput.add(infoAddress);
		//eastAddressAndInput.add(Box.createRigidArea(new Dimension(10, 1)));
	}
	
	private void postCodeAndInput() {
		eastPostCodeAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastPostCodeAndInput.setLayout(theLayout);
		postalCode = new JLabel(" Postal Code:   ");
		infoPostCode = new JTextField(15);
		eastPostCodeAndInput.add(postalCode);
		eastPostCodeAndInput.add(infoPostCode);
	}
	
	private void phnAndInput() {
		eastPhnAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastPhnAndInput.setLayout(theLayout);
		phnNum = new JLabel("Phone Number:   ");
		infoPhnNum = new JTextField(15);
		//eastPhnAndInput.add(Box.createRigidArea(new Dimension(5, 1)));
		eastPhnAndInput.add(phnNum);
		eastPhnAndInput.add(infoPhnNum);
	}
	
	private void clntTypeAndInput() {
		eastClntTypeAndInput = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastClntTypeAndInput.setLayout(theLayout);
		clientType = new JLabel("Client Type:   ");
		String types[] = {"Residential", "Commercial"};
		comboBox = new JComboBox(types); 
		//eastClntTypeAndInput.add(Box.createRigidArea(new Dimension(5, 1)));
		eastClntTypeAndInput.add(clientType);
		eastClntTypeAndInput.add(comboBox);
	}
	
	private void eastButtons() {
		eastButtns = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		eastButtns.setLayout(theLayout);
		save = new JButton("Save");
		delete = new JButton("Delete");
		clear = new JButton("Clear");
		//eastButtns.add(Box.createRigidArea(new Dimension(5, 1)));
		eastButtns.add(save);
		eastButtns.add(delete);
		eastButtns.add(clear);
	}

	private void makeRadioButtonGroup() {
		btnGrp = new ButtonGroup();

		radioClientId = new JRadioButton("Client ID");
		radiolName = new JRadioButton("Last Name");
		radioClntType = new JRadioButton("Client Type");
		btnGrp.add(radioClientId);
		btnGrp.add(radiolName);
		btnGrp.add(radioClntType);
	}
	
	public JRadioButton getRadioClientId() {
		return radioClientId;
	}
	
	private void arrangeAllComponents(){
		westPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2));
		customerPanel = new JPanel();
		customerPanel.setLayout(new GridLayout(1,2));
		customerPanel.add(westPanel);
		customerPanel.add(eastPanel);
	}

	public JPanel getTheCustomerPanel() {
		return customerPanel;
	}
	
	public void addSearchButtonListner(ActionListener listenForSearchButton) {
		search.addActionListener(listenForSearchButton);
	}
	
	public void addClearSearchButtonListner(ActionListener listenForClearSearchButton) {
		clearSearch.addActionListener(listenForClearSearchButton);
	}
	
	public void addSaveButtonListner(ActionListener listenForSaveButton) {
		save.addActionListener(listenForSaveButton);
	}
	
	public void addDeleteButtonListner(ActionListener listenForDeleteButton) {
		delete.addActionListener(listenForDeleteButton);
	}
	
	public void addClearButtonListner(ActionListener listenForSearchButton) {
		clear.addActionListener(listenForSearchButton);
	}

	public JRadioButton getRadioLName() {
		return radiolName;
	}

	public JRadioButton getRadioClientType() {
		return radioClntType;
	}

	public JTextField getSearchField() {
		return searchField;
	}
	
	public JTextArea getResultDisplay() {
		return resultDisplay;
	}

	public JTextField getInfoID() {
		return infoId;
	}

	public JTextField getInfoFName() {
		return infoFName;
	}

	public JTextField getInfoLName() {
		return infoLName;
	}

	public JTextField getInfoFAddress() {
		return infoAddress;
	}

	public JTextField getInfoPostCode() {
		return infoPostCode;
	}

	public JTextField getInfoPhnNum() {
		return infoPhnNum;
	}

	public JComboBox getComboBox() {
		return comboBox;
	}
}
