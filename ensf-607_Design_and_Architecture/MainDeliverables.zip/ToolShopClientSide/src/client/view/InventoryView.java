package client.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class InventoryView {
	private JLabel toolQueries, toolSearchType, toolEnterSrchParam, label,toolSrchResult;
    private ButtonGroup toolBtnGrp;
    private JRadioButton radioToolId, radioToolName;
    private JTextField toolSrchField, decreaseAmountField;
    private JTextArea toolResultDisplay;
    private JButton listAllTools, toolSrch, toolClearSrch, checkQuantity, printOrder, itemDecreaseButton;
    private JScrollPane scrollPane;
    private JPanel allToolPanel, toolFieldAndButtons, inventoryPanel, decreasePanel;

    public InventoryView() {
    	makeInventoryComponent();
    }
    
    private void makeInventoryComponent() {
		JPanel header = new JPanel();
		FlowLayout headerLayout = new FlowLayout(FlowLayout.CENTER);
		FlowLayout layout = new FlowLayout(FlowLayout.LEFT);
		header.setLayout(headerLayout);
		toolQueries = new JLabel("Tool Query and Transaction");
		Font font = new Font("Courier", Font.BOLD,16);
		toolQueries.setFont(font);
		header.add(toolQueries);
		makeAllSearchComponent();
		toolSearchType = new JLabel("Select parameter type:");
		JPanel radioLabel = new JPanel();
		radioLabel.setLayout(layout);
		radioLabel.add(toolSearchType);
		makeToolRadioButtonGroup();
		JPanel radios = new JPanel();
		radios.setLayout(layout);
		radios.add(radioToolId);
		radios.add(radioToolName);
		toolEnterSrchParam = new JLabel("Enter the parameter below:");
		JPanel searchLabel = new JPanel();
		searchLabel.setLayout(layout);
		searchLabel.add(toolEnterSrchParam);
		makeToolFieldAndButtonsPanel();
		makeDecreaseItemPanel();
		toolSrchResult = new JLabel("Query Result");
		JPanel resultLabel = new JPanel();
		resultLabel.setLayout(layout);
		resultLabel.add(toolSrchResult);
		JPanel resultArea = new JPanel();
		resultArea.setLayout(layout);
		toolResultDisplay = new JTextArea(30, 60);
		toolResultDisplay.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 5));
		scrollPane = new JScrollPane(toolResultDisplay);
		resultArea.add(scrollPane);
		
		inventoryPanel = new JPanel();
		inventoryPanel.setLayout(new BoxLayout(inventoryPanel, BoxLayout.Y_AXIS));
		inventoryPanel.add(header);
		inventoryPanel.add(Box.createVerticalStrut(10));
		inventoryPanel.add(allToolPanel);
		inventoryPanel.add(Box.createVerticalStrut(30));
		inventoryPanel.add(radioLabel);
		inventoryPanel.add(radios);
		inventoryPanel.add(Box.createVerticalStrut(20));
		
		inventoryPanel.add(searchLabel);
		inventoryPanel.add(toolFieldAndButtons);
		inventoryPanel.add(Box.createVerticalStrut(20));
		inventoryPanel.add(decreasePanel);
		inventoryPanel.add(Box.createVerticalStrut(30));
		inventoryPanel.add(resultLabel);
		inventoryPanel.add(resultArea);
	}
    
    private void makeToolFieldAndButtonsPanel() {
		toolFieldAndButtons = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		toolFieldAndButtons.setLayout(theLayout);
		toolSrchField = new JTextField(10);
		toolSrch = new JButton("Search Tool");
		toolClearSrch = new JButton("Clear");
		checkQuantity = new JButton("Check Quantity");
		toolFieldAndButtons.add(toolSrchField);
		toolFieldAndButtons.add(toolSrch);
		toolFieldAndButtons.add(checkQuantity);
		toolFieldAndButtons.add(toolClearSrch);
		
	}
	
	private void makeDecreaseItemPanel() {
		decreasePanel = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		decreasePanel.setLayout(theLayout);
		label = new JLabel("Enter decrease amount:");
		decreaseAmountField = new JTextField(6);
		itemDecreaseButton = new JButton("Decrease");
		decreasePanel.add(label);
		decreasePanel.add(decreaseAmountField);
		decreasePanel.add(itemDecreaseButton);
	}


	private void makeToolRadioButtonGroup() {
		toolBtnGrp = new ButtonGroup();
		radioToolId = new JRadioButton("Tool ID");
		radioToolName = new JRadioButton("Tool Name");
		toolBtnGrp.add(radioToolId);
		toolBtnGrp.add(radioToolName);
	}


	private void makeAllSearchComponent() {
		allToolPanel = new JPanel();
		FlowLayout theLayout = new FlowLayout(FlowLayout.LEFT);
		allToolPanel.setLayout(theLayout);
		listAllTools = new JButton("List All Tools");
		printOrder = new JButton("Print Order");
		allToolPanel.add(listAllTools);
		allToolPanel.add(printOrder);
	}
	
	public JPanel getTheInventoryPanel() {
		return this.inventoryPanel;
	}
	
	//listAllTools, toolSrch, toolClearSrch, checkQuantity, printOrder, itemDecreaseButton;
	
	public void addListAllToolsButtonListener(ActionListener listenForAllToolsButton) {
		listAllTools.addActionListener(listenForAllToolsButton);
	}
	
	public void addPrintOrderButtonListener(ActionListener listenForPrintOrderButton) {
		printOrder.addActionListener(listenForPrintOrderButton);
	}
	
	public void addSearchToolButtonListener(ActionListener listenForSearchToolButton) {
		toolSrch.addActionListener(listenForSearchToolButton);
	}
	
	public void addClearSearchButtonListener(ActionListener listenForClearSearchButton) {
		toolClearSrch.addActionListener(listenForClearSearchButton);
	}
	
	public void addCheckQuantityButtonListener(ActionListener listenForCheckQuantityButton) {
		checkQuantity.addActionListener(listenForCheckQuantityButton);
	}
	
	public void addDecreaseButtonListener(ActionListener listenForDecreaseButton) {
		itemDecreaseButton.addActionListener(listenForDecreaseButton);
	}
	
	public JTextArea getToolResultDisplay() {
		return toolResultDisplay;
	}
	
	public JRadioButton getRadioToolId() {
		return radioToolId;
	}
	
	public JRadioButton getRadioToolName() {
		return radioToolName;
	}
	
	public JTextField getToolSrchField() {
		return toolSrchField;
	}
	
	public JTextField getDecreaseAmountField() {
		return decreaseAmountField;
	}
	
	public JButton getListAllTools() {
		return listAllTools;
	}

	public JButton getPrintOrder() {
		return printOrder;
	}
	
	public JButton getToolSrch() {
		return toolSrch;
	}
	
	public JButton getCheckQuantity() {
		return checkQuantity;
	}
	
	public JButton getToolClearSrch() {
		return toolClearSrch;
	}
	
	public JButton getItemDecreaseButton() {
		return itemDecreaseButton;
	}
}
