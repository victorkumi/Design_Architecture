package client.viewController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import client.view.InventoryView;
import server.model.Inventory;
import server.model.Item;

public class InventoryController {
	private InventoryView theInventoryView;
	private ObjectOutputStream socketOut;
	
	public InventoryController(InventoryView theInventoryView, ObjectOutputStream socketOut) {
		setTheInventoryView(theInventoryView);
		setSocketOut(socketOut);
		
		theInventoryView.addListAllToolsButtonListener(new ListAllToolsListener());
		theInventoryView.addPrintOrderButtonListener(new PrintOrderListener());
		theInventoryView.addSearchToolButtonListener(new SearchToolListener());
		theInventoryView.addCheckQuantityButtonListener(new CheckQuantityListener());
		theInventoryView.addClearSearchButtonListener(new ClearSearchListener());
		theInventoryView.addDecreaseButtonListener(new DecreaseListener());
	}

	
	class ListAllToolsListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String messageType = "List";
			String messageContent = "List All Tools";
			Item item = new Item(messageType, messageContent);
			
			try {
				socketOut.writeObject(item);
				socketOut.flush();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	class PrintOrderListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
	}

	class SearchToolListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String selectedRadio = "";
			if (theInventoryView.getRadioToolId().isSelected()) {
				selectedRadio = "Search Tool ID";
			}
			else if (theInventoryView.getRadioToolName().isSelected()) {
				selectedRadio = "Search Tool Last Name";
			}
			else
				selectedRadio = "";
			String messageContent = theInventoryView.getToolSrchField().getText();
			
			String messageType = selectedRadio;
			
			Item item = new Item(messageType, messageContent);
			
			try {
				socketOut.writeObject(item);
				socketOut.flush();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
	}


	class CheckQuantityListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String selectedRadio = "";
			if (theInventoryView.getRadioToolId().isSelected()) {
				selectedRadio = "Search tool and Check Quantity By ID";
			}
			else if (theInventoryView.getRadioToolName().isSelected()) {
				selectedRadio = "Search tool and Check Quantity By Tool Name";
			}
			else
				selectedRadio = "";
			String messageContent = theInventoryView.getToolSrchField().getText();
			String messageType = selectedRadio;
			
			Item item = new Item(messageType, messageContent);
			
			try {
				socketOut.writeObject(item);
				socketOut.flush();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	class DecreaseListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String selectedRadio = "";
			if (theInventoryView.getRadioToolId().isSelected()) {
				selectedRadio = "Search tool and check quantity By ID and Decrease";
			}
			else if (theInventoryView.getRadioToolName().isSelected()) {
				selectedRadio = "Search tool and check quantity By Name and Decrease";
			}
			else
				selectedRadio = "";
			String messageContent = theInventoryView.getToolSrchField().getText();
			String messageContentExtra = theInventoryView.getDecreaseAmountField().getText();
			String messageType = selectedRadio;
			
			Item item = new Item(messageType, messageContent, messageContentExtra);
			
			try {
				socketOut.writeObject(item);
				socketOut.flush();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
	}
 
	class ClearSearchListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			theInventoryView.getToolSrchField().setText("");
			theInventoryView.getDecreaseAmountField().setText("");
			theInventoryView.getToolResultDisplay().setText("");
			
		}
		
	}
	private void setSocketOut(ObjectOutputStream socketOut) {
		this.socketOut = socketOut;
		
	}

	private void setTheInventoryView(InventoryView theInventoryView) {
		this.theInventoryView = theInventoryView;
		
	}

	public void processServerReply(Object obj) {
		if (obj instanceof Inventory) {
			Inventory inventory = (Inventory)obj;
			theInventoryView.getToolResultDisplay().setText(inventory.toString());
		}
		
		else if (obj instanceof Item) {
			Item item = (Item)obj;
			String messageType = item.getMessageType();
			if (messageType.equals("Feedback Search Tool")) {
				theInventoryView.getToolResultDisplay().setText(item.toString());
			}
			else if (messageType.equals("Feedback Check Quantity")) {
				theInventoryView.getToolResultDisplay().setText(item.getNAME() + "\nQuantity: " + item.getQuantity());
			}
			else if (messageType.equals("Feedback Decrease")) {
				theInventoryView.getToolResultDisplay().setText(item.getMessageContent());
			}
		}
		
	}
}
