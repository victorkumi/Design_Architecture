package client.viewController;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectOutputStream;

import client.view.CustomerView;
import server.model.Customer;
import server.model.CustomerList;
public class CustomerController {
	private CustomerView theCustomerView;
	private ObjectOutputStream socketOut;
	
	public CustomerController(CustomerView theCustomerView, ObjectOutputStream socketOut) {
		setTheCustomerView(theCustomerView);
		setSocketOut(socketOut);

		theCustomerView.addSearchButtonListner(new SearchListener());
		theCustomerView.addSaveButtonListner(new SaveListener());
		theCustomerView.addDeleteButtonListner(new DeleteListener());
		theCustomerView.addClearSearchButtonListner(new ClearSearchListener());
		theCustomerView.addClearButtonListner(new ClearButtonListener());
	}
	
	class SearchListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String selectedRadio = "";
			if (theCustomerView.getRadioClientId().isSelected()) {
				selectedRadio = " Search Client ID";
			}
			else if (theCustomerView.getRadioLName().isSelected()) {
				selectedRadio = "Search Last Name";
			}
			else if (theCustomerView.getRadioClientType().isSelected()) {
				selectedRadio = "Search Client Type";
				System.out.println(selectedRadio);
			}
			else
				selectedRadio = "";
			
			String inputField = theCustomerView.getSearchField().getText();
			Customer customer = new Customer(selectedRadio, inputField);
			try {
				socketOut.writeObject(customer);
				socketOut.flush();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	class SaveListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String clientId = theCustomerView.getInfoID().getText();
			String firstName = theCustomerView.getInfoFName().getText();
			String lastName = theCustomerView.getInfoLName().getText();
			String address = theCustomerView.getInfoFAddress().getText();
			String postCode = theCustomerView.getInfoPostCode().getText();
			String phoneNum = theCustomerView.getInfoPhnNum().getText();
			String combo = (String)theCustomerView.getComboBox().getSelectedItem();
			String clntType = "";
			if (combo.equals("Residential"))
				clntType = "R";
			else
				clntType = "C";
			Customer customer = new Customer(Integer.parseInt(clientId), firstName, lastName, clntType, address, postCode, phoneNum);
			customer.setMessageType("Save");
			customer.setMessageContent("Save Customer");
			
			try {
				socketOut.writeObject(customer);
				socketOut.flush();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	class DeleteListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String clientId = theCustomerView.getInfoID().getText();
			String messageType = "Delete";
			String messageContent = "Delete Customer";
			Customer customer = new Customer(messageType, messageContent);
			customer.setID(Integer.parseInt(clientId));
			
			try {
				socketOut.writeObject(customer);
				socketOut.flush();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	class ClearSearchListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			theCustomerView.getSearchField().setText("");
			theCustomerView.getResultDisplay().setText("");
		}
		
	}
	
	class ClearButtonListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			theCustomerView.getInfoID().setText("");
			theCustomerView.getInfoFName().setText("");
			theCustomerView.getInfoLName().setText("");
			theCustomerView.getInfoFAddress().setText("");
			theCustomerView.getInfoPostCode().setText("");
			theCustomerView.getInfoPhnNum().setText("");
			theCustomerView.getResultDisplay().setText("");
		}
		
	}
	

	public CustomerView getTheCustomerView() {
		return theCustomerView;
	}

	public void setTheCustomerView(CustomerView theCustomerView) {
		this.theCustomerView = theCustomerView;
	}

	public ObjectOutputStream getSocketOut() {
		return socketOut;
	}

	public void setSocketOut(ObjectOutputStream socketOut) {
		this.socketOut = socketOut;
	}
	
	public void processServerReply(Object obj) {
		if (obj instanceof CustomerList) {
			CustomerList listFeedBack = (CustomerList)obj;
			theCustomerView.getResultDisplay().setText(listFeedBack.toString());
		}
		else if (obj instanceof Customer){
			Customer messageFeedback = (Customer)obj;
			theCustomerView.getResultDisplay().setText(messageFeedback.getMessageContent());
		}
	}
}
