
class Line {

	Point start, end;
	private static int classID = 0;
	private int objID;

	public Line(Point a, Point b) {
	start = a;
	end = b; 
	 objID = ++ classID;
	}
	
   
	public double distance(){
	    return Point.distance(start, end);
    }
    
    public String toString()
    {
        
	String s = "Line " + this.objID + ": starts at " + start + ", and ends at " + end;
    	return s;
    }

}
