import java.io.IOException;

public class RandomPlayer extends Player {
	RandomGenerator theGenerator;
	public RandomPlayer(String name, char mark, RandomGenerator theGenerator) {
		super(name, mark);
		// TODO Auto-generated constructor stub
		setTheGenerator(theGenerator);
	}

	private void setTheGenerator(RandomGenerator theGenerator) {
		// TODO Auto-generated method stub
		this.theGenerator = theGenerator;
	}

	@Override
	public void makeMove() throws IOException {
		// TODO Auto-generated method stub
		int row = theGenerator.discrete(0, 2);
		int col = theGenerator.discrete(0, 2);
		if (board.getMark(row, col) == board.SPACE_CHAR)
			board.addMark(row, col, mark);
		else
            makeMove();
	}

}
