import java.io.*;
public abstract class Player {
    protected String name;
    protected Board board;
    protected Player opponent;
    protected char mark;
    abstract public void makeMove() throws IOException;
    
    public Player(String name, char mark){
        this.name = name;
        this.mark = mark;
    }

    public void play() throws IOException {
        while (!isWinner()){
            this.makeMove();
            board.display();
            if(!isWinner())
            	opponent.play();
        }
    }


    public void setOpponent(Player oPlayer) {
        this.opponent = oPlayer;
    }

    public void setBoard(Board theBoard) {
        this.board = theBoard;
    }

    public boolean isWinner(){
        boolean winner = false;
        boolean tie = board.isFull();
        boolean xWins = board.xWins();
        boolean oWins = board.oWins();
        if (tie || xWins || oWins){
            winner = true;
            if (tie)
                System.out.println("GAME OVER!!! \nA TIE GAME");
            else
                System.out.println("GAME OVER!!! \n" + this.name + " wins");
            System.exit(0);
        }
        return winner;
    }

}
