import java.io.IOException;

public class BlockingPlayer extends RandomPlayer {

	public BlockingPlayer(String name, char mark, RandomGenerator theGenerator) {
		super(name, mark, theGenerator);
		// TODO Auto-generated constructor stub
	}
	
//	@Override
//	public void makeMove() throws IOException {
//		// TODO Auto-generated method stub
//	    boolean isOpponentWin = testForBlocking();
//	    if (!isOpponentWin)
//		    super.makeMove();
//	}
//	
//	private boolean testForBlocking() {
//		char opponentMark = opponent.mark;
//		boolean isOpponentWin = false;
//		for (int i = 0; i < 3; i++)
//			for (int j = 0; j < 3; j++) {
//				if (board.getMark(i, j) == board.SPACE_CHAR) {
//					board.addMark(i, j, opponent.mark);
//					if (opponentMark == board.LETTER_O)
//					    isOpponentWin = board.oWins();
//					else
//						isOpponentWin = board.xWins();
//					if (isOpponentWin) {
//						board.removeMark(i, j);
//						board.addMark(i, j, mark);
//						return isOpponentWin;
//					}
//					else
//						board.removeMark(i, j);
//				}								
//			}
//		return isOpponentWin;
//	}
	@Override
	public void makeMove() throws IOException {
		// TODO Auto-generated method stub
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++) {
				boolean isOpponentWin = testForBlocking(i, j);
				if (isOpponentWin) {
					board.addMark(i, j, mark);
					return;
				}
			}
		super.makeMove();
	}
	
	private boolean testForBlocking(int row, int col) {
		char opponentMark = opponent.mark;
		boolean isOpponentWin = false;
		if (board.getMark(row, col) == board.SPACE_CHAR) {
			board.addMark(row, col, opponent.mark);
			if (opponentMark == board.LETTER_O)
			    isOpponentWin = board.oWins();
			else
				isOpponentWin = board.xWins();
			if (isOpponentWin) {
				board.removeMark(row, col);
				return isOpponentWin;
			}
			else
				board.removeMark(row, col);
		}								
		return isOpponentWin;
	}
}
