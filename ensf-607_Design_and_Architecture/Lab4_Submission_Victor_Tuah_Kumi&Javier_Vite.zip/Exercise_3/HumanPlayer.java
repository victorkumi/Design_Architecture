import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HumanPlayer extends Player {

	public HumanPlayer(String name, char mark) {
		// TODO Auto-generated constructor stub
		super(name, mark);
	}

	@Override
	public void makeMove() throws IOException {
        int row;
        int col;
        BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
        System.out.println(this.name + ", enter the row, and enter column to play");
        row = Integer.parseInt(stdin.readLine());
        col = Integer.parseInt(stdin.readLine());
        if (row < 0 || row > 2 || col < 0 || col > 2) {
        	System.out.println("Invalid selection. Try again");
        	makeMove();
        }
        else if (board.getMark(row, col) == board.SPACE_CHAR)
            board.addMark(row, col, mark);
        else
            makeMove();
    }

}
