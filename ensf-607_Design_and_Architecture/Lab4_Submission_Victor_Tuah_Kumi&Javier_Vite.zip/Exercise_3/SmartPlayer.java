import java.io.IOException;

public class SmartPlayer extends BlockingPlayer {

	public SmartPlayer(String name, char mark, RandomGenerator theGenerator) {
		super(name, mark, theGenerator);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void makeMove() throws IOException {
		// TODO Auto-generated method stub
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++) {
				boolean isWinning = testForWinning(i, j);
				if (isWinning) {
					board.addMark(i, j, mark);
					return;
				}	
			}
		super.makeMove();
	}
	
	private boolean testForWinning(int row, int col) {
		boolean isWinning = false;
		if (board.getMark(row, col) == board.SPACE_CHAR) {
			board.addMark(row, col, mark);
			if (mark == board.LETTER_O)
			    isWinning = board.oWins();
			else
				isWinning = board.xWins();
			if (isWinning) {
				board.removeMark(row, col);
				return isWinning;
			}
			else
				board.removeMark(row, col);
		} 
		return isWinning;
	}
}
