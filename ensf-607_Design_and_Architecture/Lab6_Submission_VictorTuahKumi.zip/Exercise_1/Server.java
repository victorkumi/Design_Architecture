import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
	private Socket palinSocket;
	private ServerSocket serverSocket;
	private PrintWriter socketOut;
	private BufferedReader socketIn;
	
	public Server () {
		try {
			serverSocket = new ServerSocket (8099);
		}catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	public void checkPalindrome () {
		String line = null;
		boolean taskExist = true;
		while (taskExist) {
			try {
				line = socketIn.readLine();
				if (line == null)
					taskExist = false;
				boolean palindrome = isPalindrome(line);
				if (palindrome)
				    socketOut.println(line + " is a palindrome");
				else
					socketOut.println(line + " is NOT a palindrome");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	private boolean isPalindrome (String line) {
		if (line == null)
			return false;
		int span = line.length()/2;
		int bkCursor = line.length() - 1;
		for (int i = 0; i < span; i++) {
			char frontChar = line.charAt(i);
			char mirrorChar = line.charAt(bkCursor);
			bkCursor--;
			if (frontChar != mirrorChar)
				return false;
		}
		return true;
			
	}

	public static void main(String[] args) throws IOException{
        Server myServer = new Server();
        System.out.println("Palindrome Server is running...");
        //System.out.println("Connection accepted by the server. Server is active!");
		//Establishing the connection and performing task.
			myServer.palinSocket = myServer.serverSocket.accept();
			System.out.println("Connection accepted by the server. Server is active!");
			myServer.socketIn = new BufferedReader (new InputStreamReader(myServer.palinSocket.getInputStream()));
			myServer.socketOut = new PrintWriter (myServer.palinSocket.getOutputStream(), true);
			//myServer.socketOut.println("Connection accepted by the server. Server is active!");
			
			myServer.checkPalindrome();
			
			myServer.socketIn.close();
			myServer.socketOut.close();
			myServer.palinSocket.close();

	}

}
